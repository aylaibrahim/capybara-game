/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package yogibear;

/**
 * 
 * 
 * @author xpn8tn
 */

public class YogiBear {
    /**
     * Initializes the GUI.
     * 
     * @param args command-line arguments
     */
    public static void main(String[] args) {
        YogiBearGUI gui = new YogiBearGUI();
    }
}
